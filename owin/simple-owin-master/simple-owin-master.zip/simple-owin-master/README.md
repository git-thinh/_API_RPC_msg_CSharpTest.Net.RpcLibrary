# SimpleOwin

## Samples

Includes the following samples

* Hello world OWIN app
* OWIN app using multiple middlewares with AppFunc chaining

Web socket samples (requires IIS8+/IIS8Express+ on Windows 8+ with `#define ASPNET_WEBSOCKETS`)

* Hello world OWIN WebSocket extension sample

## Middlewares

### AspNetWebSocketMiddleware
Adds support for OWIN WebSockets extensions if running on Windows 8+ with IIS8+.

For more infomation about OWIN visit http://owin.org/
