namespace SampleApp
{
    using System;

    public class ChatLogDocument
    {
        public DateTime Created { get; set; }

        public string Message { get; set; }
    }
}